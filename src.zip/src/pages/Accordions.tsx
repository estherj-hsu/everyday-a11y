import './Accordions.scss'
import CodeExample from '../components/CodeExample'

export default function Accordions() {
  return (
    <div>
      <h1>Accordions</h1>
      <p>
        Accordions are a vertically stacked set of interactive headers that show or hide related sections of content. They are commonly used to reduce scrolling when presenting multiple sections on
        the same page. When possible, use native <code>&lt;details&gt;</code> and <code>&lt;summary&gt;</code>, which provide built-in keyboard interaction and state handling. Custom accordions
        require additional markup and logic to achieve the same behavior.
      </p>

      <section className="example">
        <h2>Accordion with Native Details</h2>
        <p>
          This example uses the native <code>&lt;details&gt;</code> element to implement an accordion-style disclosure. The <code>&lt;summary&gt;</code> acts as the interactive header, and the browser
          automatically manages keyboard interaction, focus behavior, and expanded or collapsed state.
        </p>

        <CodeExample
          code={`<details>
  <summary>Accordion Heading</summary>
  <div class="content">
    <p>Accordion content.</p>
  </div>
</details>`}
          previewCode={`<div class="accordions">
<details class="accordion">
  <summary>Why do we care so much about accessibility?</summary>
  <div class="content">
    <p class="text-small">Because small interaction details compound. Keyboard access, clear focus, and predictable behavior help more people use what we build without friction.</p>
  </div>
</details>

<details class="accordion accordion--details">
<summary>Can I make the details look prettier?</summary>
<div class="accordion-content">
  <div class="accordion-content-inner">
    <p class="text-small">
      Yes. You can style <code>&lt;details&gt;</code> and <code>&lt;summary&gt;</code>
      freely, but avoid removing focus styles or breaking the click target.
      The built-in behavior is doing important accessibility work.
    </p>
  </div>
</div>
</details>
</div>`}
        />
      </section>

      <section className="example">
        <h2>Accordion without Native Semantics</h2>
        <p>
          This example shows an accordion built with generic elements and JavaScript. Without native semantics, the accordion header must be implemented as a button, and expanded or collapsed state
          must be communicated explicitly to assistive technologies.
        </p>

        <h3>Key Requirements</h3>
        <ul>
          <li>
            Each accordion header must be a real <code>&lt;button&gt;</code> element.
          </li>
          <li>
            <code>aria-expanded</code> must accurately reflect the panel’s visible state.
          </li>
          <li>
            Values used by <code>aria-controls</code> must reference unique IDs.
          </li>
          <li>Keyboard interaction (Enter, Space, and logical Tab order) must be supported.</li>
          <li>Focus must be clearly visible when navigating by keyboard.</li>
        </ul>

        <ul className="references">
          <li>
            <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/name-role-value">4.1.2 Name, Role, Value</a>;{' '}
            <a href="https://www.w3.org/WAI/WCAG22/Understanding/keyboard">2.1.1 Keyboard</a>; <a href="https://www.w3.org/WAI/WCAG22/Understanding/headings-and-labels">2.4.6 Headings and Labels</a>;{' '}
            <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-visible">2.4.7 Focus Visible</a>
          </li>
          <li>
            <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA5">ARIA5</a>, <a href="https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA4">ARIA4</a>,{' '}
            <a href="https://www.w3.org/WAI/WCAG22/Techniques/general/G90">G90</a>, <a href="https://www.w3.org/WAI/WCAG22/Techniques/general/G131">G131</a>,{' '}
            <a href="https://www.w3.org/WAI/WCAG22/Techniques/general/G149">G149</a>, <a href="https://www.w3.org/WAI/WCAG22/Techniques/general/G165">G165</a>
          </li>
        </ul>

        <CodeExample
          code={`<div class="accordion">
  <div class="accordion-header">
    <h3>
      <button
        aria-expanded="false"
        aria-controls="example-accordion">
        Accordion Heading
      </button>
    </h3>
  </div>
  <div class="accordion-content">
    <div
      id="example-accordion"
      class="accordion-content-inner" hidden>
      <p>Accordion content.</p>
    </div>
  </div>
</div>`}
          previewCode={`<p class="preview-hint text-small">💡 Try using the keyboard to see focus behaviour.</p><div class="accordions">
<div class="accordion" data-accordion="closed">
  <div class="accordion-header">
    <h3 class="h4">
      <button
        aria-expanded="false"
        aria-controls="why-do-we-care-so-much-about-accessibility">
        Why do we care so much about accessibility?
      </button>
    </h3>
  </div>
  <div class="accordion-content">
    <div
      id="why-do-we-care-so-much-about-accessibility"
      class="accordion-content-inner" hidden>
      <p class="text-small">Because small interaction details compound. Keyboard access, clear focus,and predictable behavior help more people use what we build withoutfriction.
      </p>
    </div>
  </div>
</div>
  <div class="accordion" data-accordion="closed">
    <div class="accordion-header">
      <h3 class="h4">
        <button
          aria-expanded="false"
          aria-controls="can-i-just-use-divs-for-accordions">
          Can I just use divs for accordions?
        </button>
      </h3>
    </div>
    <div class="accordion-content">
      <div
        id="can-i-just-use-divs-for-accordions"
        class="accordion-content-inner" hidden>
        <p class="text-small">
          You can, but then you’re responsible for keyboard interaction, focus
          management, and state announcements. Native elements do that work for
          free, and they don’t miss edge cases.
        </p>
      </div>
    </div>
  </div>
</div></div>`}
        />

        <h3>Accordion Animation Considerations</h3>
        <p>
          Animating accordion height directly can cause layout thrashing and jank. Using a grid-based approach allows the panel to <mark>animate smoothly without measuring content height</mark> in
          JavaScript.
        </p>
        <p>⚠️ With a fixed transition duration (0.3s here), the perceived animation speed varies with content length, with longer panels appearing to move faster.</p>

        <CodeExample
          language="css"
          code={`.accordion {
  &:has([aria-expanded="true"]) {
    .accordion-content {
      grid-template-rows: 1fr;
    }
  }
  .accordion-content {
    display: grid;
    grid-template-rows: 0fr;
    transition: grid-template-rows 0.3s;

    .accordion-content-inner {
      min-height: 0;
      overflow: hidden;
    }
  }
}`}
          showPreview={false}
        />
      </section>
    </div>
  )
}
