import SectionHeading from '../components/SectionHeading'
import TableOfContent from '../components/TableOfContent'
import { TocProvider } from '../contexts/TocContext'
import CodeExample from '../components/CodeExample'
import './Foundations.scss'

export default function Foundations() {
  return (
    <TocProvider>
      <div className="foundations">
        <h1>Foundations</h1>
        <p>Accessibility fundamentals that everything else builds on. Get these right and many problems simply never appear.</p>

        <TableOfContent />

        <section>
          <SectionHeading id="semantics">Semantics</SectionHeading>
          <p>
            <mark>Semantic HTML is the cheapest accessibility win you will ever get.</mark>
          </p>
          <p>
            Use native HTML elements for what they are meant to do. Buttons are buttons. Links navigate. Headings describe structure. Semantics convey relationships programmatically, giving assistive
            technologies meaning without extra work and reducing the need for ARIA.
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/info-and-relationships">1.3.1 Info and Relationships</a>
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G115">G115</a>, <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G140">G140</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="keyboard-interaction">Keyboard Interaction</SectionHeading>
          <p>
            <mark>Keyboards are not a fallback, they are a primary input.</mark>
          </p>
          <p>
            Everything must be usable with a keyboard alone. This includes logical tab order, no keyboard traps, and no interactions that rely on hover or pointer-only input. If you cannot operate it
            without a mouse, it is broken.
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/keyboard">2.1.1 Keyboard</a>;{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/no-keyboard-trap">2.1.2 No Keyboard Trap</a>
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G202">G202</a>, <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G90">G90</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="focus-management">Focus Management</SectionHeading>
          <p>
            <mark>Focus is how users know where they are.</mark>
          </p>
          <p>
            Focus should move predictably and intentionally. When dialogs open, focus moves inside. When they close, focus returns. After route or view changes, users should not be left stranded in
            the DOM.
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-order">2.4.3 Focus Order</a>
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G59">G59</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="aria-when-when-not-to-use">ARIA (When &amp; When Not to Use)</SectionHeading>
          <p>
            <mark>No ARIA is better than bad ARIA.</mark>
          </p>
          <p>
            ARIA exists to fill semantic gaps that HTML cannot express on its own. It should never be used to fix broken semantics. Incorrect ARIA can actively make interfaces harder to use with
            assistive technologies.
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/name-role-value">4.1.2 Name, Role, Value</a>
            </li>
            <li>
              <strong>Examples</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/aria/ARIA1">ARIA1</a>, <a href="https://www.w3.org/WAI/WCAG21/Techniques/aria/ARIA5">ARIA5</a>,{' '}
              <a href="https://www.w3.org/WAI/WCAG21/Techniques/aria/ARIA16">ARIA16</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="visual-hierarchy">Visual Hierarchy</SectionHeading>
          <p>
            <mark>Clarity beats cleverness, every time.</mark>
          </p>
          <p>Accessibility also lives in what people see. If users cannot visually understand or operate the interface, assistive technology support alone will not save it.</p>
        </section>

        <section>
          <SectionHeading id="visually-hidden">Visually Hidden Content</SectionHeading>
          <p>
            <mark>Visual simplicity should not reduce meaning.</mark>
          </p>
          <p>
            Visually hidden content is text that is available to screen readers but not visible on the screen. It is commonly used to provide accessible names, additional context, or instructions
            without changing the visual UI.
          </p>
          <CodeExample
            language="css"
            code={`.visually-hidden {
  clip: rect(0 0 0 0);
  clip-path: inset(50%);
  height: 1px;
  overflow: hidden;
  position: absolute;
  white-space: nowrap;
  width: 1px;
}`}
            showPreview={false}
          />
        </section>

        <section>
          <SectionHeading id="focus-appearance">Focus Appearance</SectionHeading>
          <p>
            <mark>Focus should be obvious, not decorative.</mark>
          </p>
          <p>Focus indicators must be clearly visible, high-contrast, and persistent. Removing outlines without a meaningful replacement breaks keyboard usability.</p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-visible">2.4.7 Focus Visible</a>;{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum">2.4.11 Focus Not Obscured</a> (AA);{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-enhanced">2.4.12 Focus Not Obscured</a> (AAA);{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance">2.4.13 Focus Appearance</a> (WCAG 2.2)
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G149">G149</a>, <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G165">G165</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="motion-reduced-motion">Motion &amp; Reduced Motion</SectionHeading>
          <p>
            <mark>Motion is optional, comprehension is not.</mark>
          </p>
          <p>
            Animations should support understanding, not distract or disorient. Motion triggered by interaction must respect reduced motion preferences and avoid causing dizziness or cognitive
            overload.
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions">2.3.3 Animation from Interactions</a>
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G219">G219</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="touch-target-spacing">Touch Target &amp; Spacing</SectionHeading>
          <p>
            Interactive elements need sufficient size (<mark>at least 24 by 24 px</mark>) and spacing to be used comfortably. Small targets increase error rates and fatigue, especially on touch
            devices.
          </p>
          <p>
            <mark>Precision should not be required to succeed.</mark>
          </p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG21/Understanding/target-size">2.5.5 Target Size</a> (AAA, WCAG 2.1);{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum">2.5.8 Target Size</a> (AA, WCAG 2.2)
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G207">G207</a>
            </li>
          </ul>
        </section>

        <section>
          <SectionHeading id="icon-only-ui-labeling">Icon-only UI &amp; Labeling</SectionHeading>
          <p>
            <mark>Recognition beats interpretation.</mark>
          </p>
          <p>Icons without text rely on interpretation. If meaning is not universally obvious, provide a visible label or a clear accessible name. Tooltips do not count as labels.</p>
          <ul className="references">
            <li>
              <strong>WCAG</strong> <a href="https://www.w3.org/WAI/WCAG22/Understanding/non-text-content">1.1.1 Non-text Content</a>;{' '}
              <a href="https://www.w3.org/WAI/WCAG22/Understanding/label-in-name">2.5.3 Label in Name</a>
            </li>
            <li>
              <strong>Techniques</strong> <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G94">G94</a>, <a href="https://www.w3.org/WAI/WCAG21/Techniques/general/G208">G208</a>
            </li>
          </ul>
        </section>
      </div>
    </TocProvider>
  )
}
