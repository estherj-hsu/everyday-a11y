import { Link } from 'react-router-dom'
import './Home.scss'

export default function Home() {
  return (
    <div className="home">
      <h1 className="logo" aria-label="Everyday Accessibility">
        Everyday <span>A</span>ccessibility
      </h1>
      <p className="h3">Practical UI & Interaction A11y for Makers</p>
      <p>
        Accessibility makes what we build usable for everyone. It improves clarity, consistency, and reduces barriers that stop people from completing even simple tasks. It is not an add-on or a final
        checklist. It is part of good UI, solid engineering, and thoughtful design.
      </p>
      <p>
        Everyday Accessibility focuses on practical patterns you can apply right away. Clear explanations. Real examples. No overwhelming rules or unnecessary jargon. Just guidance to help developers
        and designers build interfaces that work for everyone.
      </p>

      <div className="home-links">
        <Link to="/patterns" className="btn">
          Patterns
        </Link>
        <Link to="/foundations" className="btn">
          Foundations
        </Link>
        <Link to="/check-fix" className="btn">
          Check & Fix
        </Link>
      </div>
    </div>
  )
}
